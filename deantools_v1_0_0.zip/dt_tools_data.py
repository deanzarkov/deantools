DT_TOOLS_DATA = {
    'EFS': {
        'id_name'       : 'dt_eye_features_set',
        'name'          : "Eye Features Set",
        'description'   : "A procedural generator for creating fully customizable stylized or realistic eye/eyebrow/eyelashes assets in seconds using a non-destructive workflow.",
        'latest_version': (1, 0, 0),
        'gr_url'        : "https://deanzarkov.gumroad.com/l/eye-features-set",
        'sh_url'        : "https://superhivemarket.com/products/eye-features-set",
        'overview_url'  : "https://www.deantools.dev/blender-tools/eye-features-set",
        'docs_url'      : "https://www.deantools.dev/blender-tools/eye-features-set/efs-docs",
    },
    
    'SHP': {
        'id_name'       : 'stylized_hair_pro',
        'name'          : "Stylized Hair Pro",
        'description'   : "A powerful feature-rich tool for creating hair strands geometry from curves. Fully procedural, allowing you to create complex hair geometry with ease.",
        'latest_version': (4, 2, 0),
        'gr_url'        : "https://deanzarkov.gumroad.com/l/stylized_hair_pro",
        'sh_url'        : "https://superhivemarket.com/products/stylized-hair-pro",
        'overview_url'  : "https://www.deantools.dev/blender-tools/stylized-hair-pro",
        'docs_url'      : "https://www.deantools.dev/blender-tools/stylized-hair-pro/shp-docs",
    }
}